class ILinter:
    def __init__(self):
        pass

    def lint(self, code):
        
        pass