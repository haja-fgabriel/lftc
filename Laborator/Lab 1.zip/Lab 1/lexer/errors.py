class TokenizerException(Exception):
    pass